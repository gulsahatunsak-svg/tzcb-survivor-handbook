TZCB Survivor Handbook — approved screenshot update

Upload index.html and the entire images/ folder to the root of your existing GitHub Pages repository, replacing the old index.html. Do not upload index.html alone: it references the eight files in images/.

The original handbook text and design are preserved; only gallery styling and the approved screenshots were added.
